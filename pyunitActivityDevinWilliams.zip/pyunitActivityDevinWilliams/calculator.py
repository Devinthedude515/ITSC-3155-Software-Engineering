#create calculator class
class Calculator:

    #create constructor for the class with no parameters
    def __init__(self):
        pass

    #create add method using a and b values
    def add(self, a, b):
        return a + b

    # create sub method using a and b values
    def sub(self, a, b):
        return a - b

    # create multiply method using a and b values
    def mul(self, a, b):
        return a * b

    # create divide method using a and b values
    def div(self, a, b):
        return a / b
